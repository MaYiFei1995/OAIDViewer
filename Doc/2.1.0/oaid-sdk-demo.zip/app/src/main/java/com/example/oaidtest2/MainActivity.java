package com.example.oaidtest2;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bun.miitmdid.core.MdidSdkHelper;
import com.example.oaidtest2.utils.CertUtil;
import com.example.oaidtest2.utils.SystemInfoUtil;

public class MainActivity extends AppCompatActivity implements DemoHelper.AppIdsUpdater {
    TextView tv_sdk, tv_sys, tv_cert, tv_info;
    Button btn_get_all_ids;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv_sdk = findViewById(R.id.tv_sdk);
        tv_sdk.setText(getSdkVersionInfo());
        tv_sys = findViewById(R.id.tv_sys);
        tv_sys.setText(getSysInfo());
        tv_cert = findViewById(R.id.tv_cert);
        tv_cert.setText(CertUtil.getCertInfo(DemoHelper.loadPemFromAssetFile(this, DemoHelper.ASSET_FILE_NAME_CERT)));
        tv_info = findViewById(R.id.tv_info);
        DemoHelper demoHelper = new DemoHelper(this);
        demoHelper.getDeviceIds(this);
        btn_get_all_ids = findViewById(R.id.btn_get_all_ids);
        btn_get_all_ids.setOnClickListener(v -> demoHelper.getDeviceIds(this));
        findViewById(R.id.btn_get_oaid).setOnClickListener(v -> demoHelper.getDeviceIds(this,true,false,false));
        findViewById(R.id.btn_get_vaid).setOnClickListener(v -> demoHelper.getDeviceIds(this,false,true,false));
        findViewById(R.id.btn_get_aaid).setOnClickListener(v -> demoHelper.getDeviceIds(this,false,false,true));

    }

    private String getSdkVersionInfo(){
        return String.format("OAID SDK Test\nVersion: 2.1.0 (%d)", MdidSdkHelper.SDK_VERSION_CODE);
    }

    private String getSysInfo(){
        return String.format("Time: %s\nBrand: %s\nManufacturer: %s\nModel: %s\nAndroidVersion: %s",
                SystemInfoUtil.getSystemTime(),
                SystemInfoUtil.getDeviceBrand(),
                SystemInfoUtil.getDeviceManufacturer(),
                SystemInfoUtil.getSystemModel(),
                SystemInfoUtil.getSystemVersion()
        );
    }

    @Override
    public void onIdsValid(String ids) {
        runOnUiThread(() -> {
            tv_info.setText("OAID: \n" + ids);
            tv_sys.setText(getSysInfo());
        });
    }
}