package com.example.oaidtest2;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bun.miitmdid.core.MdidSdkHelper;
import com.bun.miitmdid.interfaces.IPermissionCallbackListener;
import com.example.oaidtest2.utils.CertUtil;
import com.example.oaidtest2.utils.SystemInfoUtil;

import java.util.List;

public class MainActivity extends AppCompatActivity implements DemoHelper.AppIdsUpdater {
    public static final String TAG = "MainActivity";
    TextView tv_sdk, tv_sys, tv_cert, tv_info,tv_permission,tv_timeConsume;
    Button btn_refresh;
    String lib = "msaoaidsec";
    DemoHelper demoHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv_sdk = findViewById(R.id.tv_sdk);
        tv_sdk.setText(getSdkVersionInfo());
        tv_sys = findViewById(R.id.tv_sys);
        tv_sys.setText(getSysInfo());
        tv_cert = findViewById(R.id.tv_cert);
        tv_cert.setText(CertUtil.getCertInfo(DemoHelper.loadPemFromAssetFile(this,DemoHelper.ASSET_FILE_NAME_CERT)));
        tv_info = findViewById(R.id.tv_info);
        demoHelper = new DemoHelper(this,lib);
        demoHelper.getDeviceIds(this);
        btn_refresh = findViewById(R.id.btn_get_all_ids);
        btn_refresh.setOnClickListener(v -> {
            demoHelper.getDeviceIds(this);
        });
         findViewById(R.id.btn_get_oaid).setOnClickListener(v -> demoHelper.getDeviceIds(this,true,false,false));
         findViewById(R.id.btn_get_vaid).setOnClickListener(v -> demoHelper.getDeviceIds(this,false,true,false));
         findViewById(R.id.btn_get_aaid).setOnClickListener(v -> demoHelper.getDeviceIds(this,false,false,true));
    }

    @Override
    public void onIdsValid(String ids) {
        runOnUiThread(() -> {
            tv_info.setText("OAID: \n" + ids);
            tv_sys.setText(getSysInfo());
        });
        requestOaidPermission();
    }

    private String getSdkVersionInfo(){
        return String.format("OAID SDK Test\nVersion: %s (%d)", MdidSdkHelper.SDK_VERSION,MdidSdkHelper.SDK_VERSION_CODE);
    }

    private String getSysInfo(){
        return String.format("Time: %s\nBrand: %s\nManufacturer: %s\nModel: %s\nAndroidVersion: %s",
                SystemInfoUtil.getSystemTime(),
                SystemInfoUtil.getDeviceBrand(),
                SystemInfoUtil.getDeviceManufacturer(),
                SystemInfoUtil.getSystemModel(),
                SystemInfoUtil.getSystemVersion()
        );
    }


    private void requestOaidPermission(){
        if (demoHelper.getIsSupported()) {
            if (demoHelper.getIsLimited()) {
                // 如果支持请求OAID获取权限，就请求权限
                if (demoHelper.getIsSupportRequestOAIDPermission()) {
                    demoHelper.requestOAIDPermission(this, new IPermissionCallbackListener() {

                        // 获取授权成功
                        @Override
                        public void onGranted(String[] grPermission) {
                            demoHelper.getDeviceIds(MainActivity.this);
                        }

                        // 获取授权失败
                        @Override
                        public void onDenied(List<String> dePermissions) {
                            // 处理代码
                        }

                        // 禁止再次询问
                        @Override
                        public void onAskAgain(List<String> asPermissions) {
                            // 处理代码
                        }
                    });
                }
            }
        }
    }
}