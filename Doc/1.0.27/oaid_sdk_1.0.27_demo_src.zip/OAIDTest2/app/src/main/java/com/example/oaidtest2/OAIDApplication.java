package com.example.oaidtest2;

import android.app.Application;
import android.util.Log;

public class OAIDApplication extends Application implements DemoHelper.AppIdsUpdater {
    public static final String TAG = "OAIDApplication";
    @Override
    public void onCreate() {
        super.onCreate();
        DemoHelper demoHelper = new DemoHelper(this);
        demoHelper.getDeviceIds(this);
    }

    @Override
    public void onIdsValid(String ids) {
        Log.d(TAG, "onIdsValid: "+ids);
    }
}
